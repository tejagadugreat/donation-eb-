function donate(type) {
    alert("Thank you for donating " + type + "!");
}
